# res-teste-a
Resolução do teste - versão A
